'use strict';

// Keep this file as an alias for the full stream module.

module.exports = require('stream').PassThrough;
