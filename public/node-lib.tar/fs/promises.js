'use strict';

module.exports = require('internal/fs/promises').exports;
