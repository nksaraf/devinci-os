'use strict';

// Re-export process as a native module
module.exports = process;
