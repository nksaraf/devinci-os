'use strict';

module.exports = require('path').win32;
