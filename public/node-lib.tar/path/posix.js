'use strict';

module.exports = require('path').posix;
