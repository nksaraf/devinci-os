'use strict';

module.exports = require('internal/util/types');
