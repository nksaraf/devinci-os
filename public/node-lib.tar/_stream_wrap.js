'use strict';

module.exports = require('internal/js_stream_socket');
process.emitWarning('The _stream_wrap module is deprecated.',
                    'DeprecationWarning', 'DEP0125');
